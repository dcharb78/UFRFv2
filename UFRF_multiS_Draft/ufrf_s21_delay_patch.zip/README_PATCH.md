# UFRF S21/S12 Delay‑Aware Patch
(See README_PATCH.md inside for instructions.)
